// Importing the database utility
const db = require('../util/database');

// Defining the Accident class
module.exports = class Accident {
    // Constructor to initialize Accident object with accident details
    constructor(acciDate, place, numVehicle, relative, details) {
        this.acciDate = acciDate;
        this.place = place;
        this.numVehicle = numVehicle;
        this.relative = relative;
        this.details = details;
    }

    // Method to save the accident details to the database
    save() {
        // Executing the SQL query to insert accident details into the database
        return db.execute('insert into accidents_details (acciDate, place, numVehicle, relative, details) values (?, ?, ?, ?, ?)', [this.acciDate, this.place, this.numVehicle, this.relative, this.details]);
    }

    // Static method to retrieve all accidents from the database
    static getAll(){
        // Executing the SQL query to select all accident details from the database
        return db.execute('select * from accidents_details');
    }

    // Static method to retrieve accident details by code from the database
    static getByCode(code){
        // Executing the SQL query to select accident details by code from the database
        return db.execute('select * from accidents_details where code=?',[code]);
    }
}
