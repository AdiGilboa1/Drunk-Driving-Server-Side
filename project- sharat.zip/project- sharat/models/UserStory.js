// Importing the database utility
const db = require('../util/database');

// Defining the UserStory class
module.exports = class UserStory {
    // Constructor to initialize UserStory object with user story details
    constructor(fullName, age, story) {
        this.fullName = fullName;
        this.age = age;
        this.story = story;
    }

    // Method to save the user story details to the database
    save() {
        // Executing the SQL query to insert user story details into the database
        return db.execute('INSERT INTO user_story (fullName, age, story) VALUES (?, ?, ?)', [this.fullName, this.age, this.story]);
    }

    // Static method to retrieve all user stories from the database
    static getAll() {
        // Executing the SQL query to select all user stories from the database
        return db.execute('SELECT * FROM user_story');
    }
}
