// Importing the database utility
const db = require('../util/database');

// Defining the Punishment class
module.exports = class Punishment {
    // Constructor to initialize Punishment object with punishment details
    constructor(amountOfAlcohol, punishmentType, details) {
        this.amountOfAlcohol = amountOfAlcohol;
        this.punishmentType = punishmentType;
        this.details = details;
    }

    // Method to save the punishment details to the database
    save() {
        // Executing the SQL query to insert punishment details into the database
        return db.execute('INSERT INTO punishment (amountOfAlcohol, punishmentType, details) VALUES (?, ?, ?)', [this.amountOfAlcohol, this.punishmentType, this.details]);
    }

    // Static method to retrieve all punishments from the database
    static getAll() {
        // Executing the SQL query to select all punishment details from the database
        return db.execute('SELECT * FROM punishment');
    }

    // Static method to retrieve punishment details by punishment type from the database
    static getByPunishmentType(punishmentType) {
        // Executing the SQL query to select punishment details by punishment type from the database
        return db.execute('SELECT * FROM punishment WHERE punishmentType = ?', [punishmentType]);
    }
}
