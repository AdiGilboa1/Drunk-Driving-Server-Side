// Importing the database utility
const db = require('../util/database');

// Defining the User class
module.exports = class User {
    // Constructor to initialize User object with user details
    constructor(email, password, age, gender, fullName, dob) {
        this.email = email;
        this.password = password;
        this.age = age;
        this.gender = gender;
        this.fullName = fullName;
        this.dob = dob; 
    }

    // Static method to retrieve user by email and password from the database
    static getByEmailandPass(email, password) {
        // Executing the SQL query to select user by email and password from the database
        return db.execute('SELECT * FROM users WHERE email=? AND password=?', [email, password]);
    }

    // Method to save the user details to the database
    save() {
        // Executing the SQL query to insert user details into the database
        return db.execute('INSERT INTO users (email, password, age, gender, fullName, dob) VALUES (?, ?, ?, ?, ?, ?)', [this.email, this.password, this.age, this.gender, this.fullName, this.dob]);
    }

    // Static method to retrieve user by email from the database
    static getByEmail(email) {
        // Executing the SQL query to select user by email from the database
        return db.execute('SELECT * FROM users WHERE email=?', [email]);
    }
}
