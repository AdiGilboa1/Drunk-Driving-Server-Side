// Importing required modules
const express = require('express');
const bodyParser = require('body-parser');

// Importing controllers
const accidentsController = require("../controllers/accidents.js");
const punishmentsController = require("../controllers/punishments.js");
const userStoriesController = require("../controllers/userStories.js");

// Creating a router instance
const router = express.Router();
router.use(bodyParser.urlencoded({ extended: false }));

// Routes for accidents
router.get('/add-accident', accidentsController.addAccident); // Route to render add-accident form
router.post('/accidents', accidentsController.SaveAccident); // Route to save accident details
router.get('/accidents', accidentsController.getAccidents); // Route to retrieve all accidents
router.get('/accidents/:code', accidentsController.getAccidentByCode); // Route to retrieve accident by code

// Routes for punishments
router.get('/add-punishment', punishmentsController.addPunishment); // Route to render add-punishment form
router.post('/punishments', punishmentsController.SavePunishment); // Route to save punishment details
router.get('/punishments', punishmentsController.getPunishment); // Route to retrieve all punishments
router.get('/punishments/:punishmentType', punishmentsController.getPunishmentByCode); // Route to retrieve punishment by type

// Routes for user stories
router.get('/add-user-story', userStoriesController.addUserStory); // Route to render add-user-story form
router.post('/user-stories', userStoriesController.saveUserStory); // Route to save user story details
router.get('/user-stories', userStoriesController.getUserStories); // Route to retrieve all user stories
router.get('/user-stories/:id', userStoriesController.getUserStoryById); // Route to retrieve user story by ID

// Home page route
router.get('/', accidentsController.homePage);

// Exporting the router
module.exports = router;
