// Importing required modules
const express = require('express');

// Importing auth controller
const authController = require("../controllers/auth.js");

// Creating a router instance
const router = express.Router();

// Route to render login form
router.get('/login', authController.getLogin);
// Route to handle login form submission
router.post('/login', authController.postLogin);
// Route to render sign-up form
router.get('/signup', authController.getSignUp);
// Route to handle sign-up form submission
router.post('/signup', authController.SignUp);

// Exporting the router
module.exports = router;
