const path = require('path'); // Module for working with file paths
const express = require('express'); // Framework for building web applications
const session = require('express-session'); // Middleware for managing sessions
const app = express(); // Creating an Express application instance
const adminRoutes = require('./routes/admin'); // Importing admin routes
const authRoutes = require('./routes/auth'); // Importing authentication routes
const errorController = require('./controllers/error'); // Importing error controller

// Setting view engine to EJS
app.set('view engine', 'ejs');

// Configuring session middleware
app.use(session({
    secret: "thisismysecrctekeyfhrgfgrfrty84fwir767", // Secret key for session encryption
    saveUninitialized: false, // Disabling saving uninitialized sessions
    resave: false  // Disabling session resaving
}));

// Serving static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));
// Registering admin routes
app.use(adminRoutes);
// Registering authentication routes
app.use(authRoutes);
// Registering error controller middleware
app.use(errorController.showError);

// Starting the server on port 3000
app.listen(3000,()=>{
    console.log("app is listening on port 3000")
});
