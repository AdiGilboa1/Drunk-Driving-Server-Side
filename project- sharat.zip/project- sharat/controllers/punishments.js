// Importing the Punishment model
const Punishment = require('../models/Punishment');

// Controller function to save punishment details
exports.SavePunishment = (req, res, next) => {
    // Destructuring request body to extract punishment details
    const { amountOfAlcohol, punishmentType, details } = req.body;
    // Creating a new Punishment instance with the extracted details
    const punishment = new Punishment(amountOfAlcohol, punishmentType, details);
    // Saving the punishment to the database
    punishment.save()
        .then(() => {
            // Redirecting to the home page after successful save
            res.redirect('/');
        })
        .catch(err => console.log(err)); // Logging error if save operation fails
}

// Controller function to retrieve all punishments
exports.getPunishment = (req, res, next) => {
    // Retrieving all punishments from the database
    Punishment.getAll()
        .then(([rows]) => {
            // Rendering the punishment view with retrieved punishment data
            res.render('punishment', { punishments: rows });
        })
        .catch(err => console.log(err)); // Logging error if retrieval fails
}

// Controller function to retrieve a punishment by punishment type
exports.getPunishmentByCode = (req, res, next) => {
    // Extracting punishment type code from request parameters
    const code = req.params.code;
    // Retrieving punishment details by punishment type from the database
    Punishment.getByPunishmentType(code)
        .then((prod) => {
            // Rendering the punishment view with retrieved punishment data
            console.log(prod[0][0]);
            res.render('punishment', { punishment: prod[0][0] });
        })
        .catch(err => console.log(err)); // Logging error if retrieval fails
}

// Controller function to render the form for adding a new punishment
exports.addPunishment = (req, res, next) => {
    // Rendering the add-punishment view
    res.render('add-punishment');
}

// Controller function to render the home page
exports.homePage = (req, res, next) => {
    // Rendering the index view
    res.render('index');
}

// Controller function to render a 404 error page
exports.showError = (req, res, next) => {
    // Rendering the 404 error view
    res.status(404).render('404');
}
