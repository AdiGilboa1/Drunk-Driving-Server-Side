// Importing the User model and bcrypt for password hashing
const User = require('../models/User');
const bcrypt = require('bcryptjs');

// Controller function to render the login page
exports.getLogin = (req, res, next) => {
    // Logging session information
    console.log(req.session);
    // Rendering the login view
    res.render('auth/login');
}

// Controller function to handle login form submission
exports.postLogin = (req, res, next) => {
    // Extracting email and password from request body
    const email = req.body.email;
    const password = req.body.password;
    // Retrieving user by email from the database
    User.getByEmail(email)
        .then(user => {
            if (!user[0][0]) {
                // Redirecting if user is not found
                console.log("User not found");
                res.redirect('/login');
            } else {
                // Comparing hashed password with input password
                return bcrypt.compare(password, user[0][0].password)
                    .then(doMatch => {
                        if (doMatch) {
                            // Redirecting if user and password match
                            console.log("User and password match");
                            req.session.isLoggedIn = true;
                            req.session.userId = email;
                            res.redirect('/');
                        } else {
                            // Redirecting if password does not match
                            console.log("Password does not match");
                            res.redirect('/login');
                        }
                    })
            }
        })
        .catch(err => console.log(err)); // Logging error if any
}

// Controller function to render the sign-up page
exports.getSignUp = (req, res, next) => {
    // Logging a message
    console.log("Get signup");
    // Rendering the signup view
    res.render('auth/signup');
}

// Controller function to handle sign-up form submission
exports.SignUp = (req, res, next) => {
    // Extracting user details from request body
    const email = req.body.email;
    const password = req.body.password;
    const age = req.body.age;
    const gender = req.body.gender;
    const fullName = req.body.fullName;
    const dob = req.body.dob; // Retrieve date of birth from request body

    // Checking if user already exists
    User.getByEmail(email)
        .then(user => {
            if (user[0][0]) {
                // Redirecting if user already exists
                console.log("User is found in db");
                res.redirect('/signup');
            } else {
                // Hashing password
                return bcrypt.hash(password, 12)
                    .then(hashedPassword => {
                        console.log(hashedPassword);
                        // Creating a new user instance with hashed password and other details
                        const user = new User(email, hashedPassword, age, gender, fullName, dob); // Pass date of birth to User constructor
                        // Saving the user to the database
                        user.save();
                        // Setting session variables for logged-in user
                        req.session.isLoggedIn = true;
                        req.session.userId = email;
                        // Redirecting to home page after sign-up
                        res.redirect('/');
                    });
            }
        })
        .catch(err => console.log(err)); // Logging error if any
}
