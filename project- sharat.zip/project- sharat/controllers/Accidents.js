// Importing the Accident model
const Accident = require('../models/accident');

// Controller function to save accident details
exports.SaveAccident = (req, res, next) => {
    // Destructuring request body to extract accident details
    const { acciDate, place, numVehicle, relative, details } = req.body;
    // Creating a new Accident instance with the extracted details
    const accident = new Accident(acciDate, place, numVehicle, relative, details);
    // Saving the accident to the database
    accident.save()
        .then(() => {
            // Redirecting to the home page after successful save
            res.redirect('/');
        })
        .catch(err => console.log(err)); // Logging error if save operation fails
}

// Controller function to retrieve all accidents
exports.getAccidents = (req, res, next) => {
    // Retrieving all accidents from the database
    let accidents = Accident.getAll()
        .then(([rows]) => {
            // Rendering the accidents view with retrieved accident data
            res.render('accidents', { accidents: rows });
        })
        .catch(err => console.log(err)); // Logging error if retrieval fails
}

// Controller function to retrieve an accident by code
exports.getAccidentByCode = (req, res, next) => {
    // Extracting accident code from request parameters
    const code = req.params.code;
    // Retrieving accident details by code from the database
    Accident.getByCode(code)
        .then((prod) => {
            // Rendering the accident view with retrieved accident data
            console.log(prod[0][0]);
            res.render('accident', { accident: prod[0][0] });
        })
        .catch(err => console.log(err)); // Logging error if retrieval fails
}

// Controller function to render the form for adding a new accident
exports.addAccident = (req, res, next) => {
    // Rendering the add-accident view
    res.render('add-accident');
}

// Controller function to render the home page
exports.homePage = (req, res, next) => {
    // Rendering the index view
    res.render('index');
}

// Controller function to render a 404 error page
exports.showError = (req, res, next) => {
    // Rendering the 404 error view
    res.status(404).render('404');
}
