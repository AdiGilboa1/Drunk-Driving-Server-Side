// Controller function to render a 404 error page
exports.showError = (req, res, next) => {
    // Rendering the 404 error view with custom page title
    res.status(404).render('404', { pageTitle: 'Page Not Found' });
}
