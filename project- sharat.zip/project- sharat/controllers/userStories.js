// Importing the UserStory model
const UserStory = require('../models/UserStory');

// Controller function to save user story details
exports.saveUserStory = (req, res, next) => {
    // Destructuring request body to extract user story details
    const { fullName, age, story } = req.body;
    // Creating a new UserStory instance with the extracted details
    const userStory = new UserStory(fullName, age, story);
    // Saving the user story to the database
    userStory.save()
        .then(() => {
            // Redirecting to the home page after successful save
            res.redirect('/');
        })
        .catch(err => console.log(err)); // Logging error if save operation fails
}

// Controller function to retrieve all user stories
exports.getUserStories = (req, res, next) => {
    // Retrieving all user stories from the database
    UserStory.getAll()
        .then(([rows]) => {
            // Rendering the user-stories view with retrieved user story data
            res.render('user-stories', { userStories: rows });
        })
        .catch(err => console.log(err)); // Logging error if retrieval fails
}

// Controller function to retrieve a user story by ID
exports.getUserStoryById = (req, res, next) => {
    // Extracting user story ID from request parameters
    const id = req.params.id;
    // Retrieving user story by ID from the database
    UserStory.getById(id)
        .then((userStory) => {
            // Rendering the user-story view with retrieved user story data
            console.log(userStory);
            res.render('user-story', { userStory: userStory[0] });
        })
        .catch(err => console.log(err)); // Logging error if retrieval fails
}

// Controller function to render the form for adding a new user story
exports.addUserStory = (req, res, next) => {
    // Rendering the add-user-story view
    res.render('add-user-story');
}

// Controller function to render the home page
exports.homePage = (req, res, next) => {
    // Rendering the index view
    res.render('index');
}

// Controller function to render a 404 error page
exports.showError = (req, res, next) => {
    // Rendering the 404 error view
    res.status(404).render('404');
}
